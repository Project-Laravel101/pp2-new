<?php

namespace App\Http\Controllers;

use App\City;
use Illuminate\Http\Request;

class CityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cities= City::orderBy('id')->paginate(5);
        return view('city.cities',['cities'=>$cities]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('city.addcity');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request ,[
        'name'=> 'required|max:20|unique:cities,name',
        'c_img'=> 'image|mimes:jpeg,png,jpg|required|max:1999',
            ]);

        //Image Upload Handling
            if($request->hasFile('c_img'))
            {
                //getting image with extension
                $ImgWithExt =$request->file('c_img')->getClientOriginalName();

                //Seperating file name using php function
                $image = pathinfo($ImgWithExt, PATHINFO_FILENAME);
                //Seperating extension
                $extension = $request->file('c_img')->getClientOriginalExtension();

                //To prevent from same filename in DB
                $Imgfile= $image.'_'.time().'.'.$extension;

                //Image Upload
                $path =$request->file('c_img')->storeAs('public/upload_img', $Imgfile);
            }
            else
            {
                $Imgfile = 'noimage.jpg';
            }


        // Create New City
        $city= new City([
            'name'=>$request->input('name'),
            'c_img'=>$Imgfile,
        ]);
        $city->save();

        return redirect('cities')->with('success', 'City Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $cities = City::find($id);
        return view('city.editcity',['cities'=>$cities]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $city= City::find($id);
        $city->delete();

        return redirect('cities')->with('success', 'City Deleted Successfully');
    }
}
