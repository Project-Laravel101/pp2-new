<!doctype html>
<html lang="en">
<head>

        <title>Admin Sign In</title>

    <link rel="stylesheet" href="{{asset('css/master/bootstrap.min.css')}}" >
    <link rel="stylesheet" href="{{asset("css/style.css")}}" >



</head>
<body>
<div class="container w-75  p-1 ">
<div class="login-form">
    <form action="#" method="post">
        <div><img src="{{asset('images/24px.svg')}}"></div>
        <h4 class="modal-title">Admin Portal</h4>
        <div class="col-md-4"></div>
        <div class="form-group">
            <input type="text" class="form-control col-md-4" placeholder="Username" required="required">
        </div>
        <div class="col-md-4"></div>
        <div class="form-group">
            <input type="password" class="form-control col-md-4" placeholder="Password" required="required">
        </div>
        <div class="col-md-4"></div>
             <div class="form-group small clearfix">
                 <label class="checkbox-inline"><input type="checkbox"> Remember me</label>
            </div>
        <div class="col-sm-5"></div>
        <input type="submit" class="btn btn-primary btn-block btn-lg col-md-2" value="Login">
        <div class="form-group">
            <div class="col-sm-5"></div>
                <a href="#" class="forgot-link">Forgot Password?</a>
        </div>
</form>
</div>
</div>
</div>

</body>
</html>