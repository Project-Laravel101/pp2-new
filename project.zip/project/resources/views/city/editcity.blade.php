@extends('inc.master')

<head>
    @section('title')
       Edit City
    @endsection
</head>

@section('breadcrumb-nav')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cities</li>
            <li class="breadcrumb-item active" aria-current="page">Edit-City</li>
        </ol>
    </nav>
@endsection

@section('content')
    <div class="col-lg-2"></div>
    <div class="col-lg-auto">
        <div class="card text-white bg-dark mb-3">
            <div class="card-header">
                <strong class="card-title">Edit City</strong>
            </div>
            <div class="card-body">

                <div id="pay-invoice">
                    <div class="card-body">
                        <form action="'CityController@update', $cities->id}" method="post" class="form-horizontal" enctype="multipart/form-data">
                            @csrf
                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="text-input" class=" form-control-label">Name</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <textarea type="text" name="name" class="form-control text-white bg-dark mb-3" >{{$cities->name}}</textarea>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="text-input" class=" form-control-label">Image</label>
                                </div>
                                <div class="col-12 col-md-7">
                                    <input type="file" name="c_img" placeholder="Upload">
                                </div>
                            </div>
                            <div class="row form-group"></div>
                            <div class="row form-group">
                                <div class="col-12 col-md-5">
                                </div>
                                <div class="col col-md-4">
                                    @method('PUT')
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                                <div class="col-12 col-md-3">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3"></div>

@endsection
