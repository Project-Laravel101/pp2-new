@extends('inc.master')


<head>
@section('title')
    Cities
@endsection


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Admin Portal">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico">

</head>
@section('breadcrumb-nav')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cities</li>
        </ol>
    </nav>
@endsection

@section('content')
        <!-- Content -->
        <div class="col-lg-1"></div>
        <div class="col-lg-7"><br><br>
            <a href="/cities/create"><button class="btn btn-primary">Add City</button></a>
            <br><br><br>
    @if(count($cities)>0)
                <table class="table">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                      <th scope="col">Image</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    @foreach($cities as $city)
                        <thead class="table-striped thead-light">
                        <tr>
                            <th scope="col">{{$city->id}}</th>
                            <th scope="col">{{$city->name}}</th>
                           <th scope="col"><img src="/storage/upload_img/{{$city->c_img}}"></th>
                        <th scope="col"> <form action="{{action('CityController@destroy', $city->id)}}" method="Post" >
                               @method('DELETE')
                                @csrf
                                <button class="btn btn-outline-danger">Delete</button>
                            </form>
                            <form action="{{action('CityController@edit', $city->id)}}" method="post" >
                                    @method('GET')
                                    @csrf
                                    <button class="btn btn-outline-primary">Edit</button>
                                </form>
                            </th>
                        </tr>
                        </thead>
                        @endforeach
                </table>
                {{$cities->links()}}
            @else
                <h2>No Data has been Added</h2>
        @endif
        </div>
@endsection


