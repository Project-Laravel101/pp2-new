@extends('inc.master')

<head>
    @section('title')
        Categories
    @endsection
</head>
@section('breadcrumb-nav')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cities</li>
        </ol>
    </nav>
@endsection
@section('content')

    <div class="col-lg-1"></div>
    <div class="col-lg-7">
        <a href="/categories/create"><button class="btn btn-primary">Add Category</button></a>
        <br><br><br>
        @if(count($categories)>0)
        <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
          @foreach($categories as $category)
            <thead class="table-striped thead-light">
            <tr>
                <th scope="col">{{$category->id}}</th>
                <th scope="col">{{$category->name}}</th>
                <th> <form action="{{action('CategoryController@destroy', $category->id)}}" method="post" >
                        @method('DELETE')
                        @csrf
                        <button class="btn btn-link">Delete</button>
                    </form>
                </th>
            </tr>
            </thead>
              @endforeach
    </table>
            {{$categories->links()}}
        @else
            <h2>No Data has been Added</h2>
        @endif
    </div>

@endsection




