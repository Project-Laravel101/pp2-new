<head>
<?php $__env->startSection('title'); ?>
    Cities
<?php $__env->stopSection(); ?>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Admin Portal">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico">

</head>
<?php $__env->startSection('breadcrumb-nav'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cities</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- Content -->
        <div class="col-lg-1"></div>
        <div class="col-lg-7"><br><br>
            <a href="/cities/create"><button class="btn btn-primary">Add City</button></a>
            <br><br><br>
    <?php if(count($cities)>0): ?>
                <table class="table">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                      <th scope="col">Image</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <thead class="table-striped thead-light">
                        <tr>
                            <th scope="col"><?php echo e($city->id); ?></th>
                            <th scope="col"><?php echo e($city->name); ?></th>
                           <th scope="col"><img src="/storage/upload_img/<?php echo e($city->c_img); ?>"></th>
                        <th scope="col"> <form action="<?php echo e(action('CityController@destroy', $city->id)); ?>" method="Post" >
                               <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-outline-danger">Delete</button>
                            </form>
                            <form action="<?php echo e(action('CityController@edit', $city->id)); ?>" method="post" >
                                    <?php echo method_field('GET'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-primary">Edit</button>
                                </form>
                            </th>
                        </tr>
                        </thead>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($cities->links()); ?>

            <?php else: ?>
                <h2>No Data has been Added</h2>
        <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/city/cities.blade.php ENDPATH**/ ?>