<?php echo $__env->yieldContent('navbar'); ?>



<div class="light bg-dark">

<ul class="nav">
    <li class="nav-item">
        <a class="nav-link active" href="#">Active</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
    </li>
    <li class="nav-item">
        <a class="nav-link disabled " href="#">Disabled</a>
    </span>
    </li>

</ul>
</div><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/inc/navbar.blade.php ENDPATH**/ ?>