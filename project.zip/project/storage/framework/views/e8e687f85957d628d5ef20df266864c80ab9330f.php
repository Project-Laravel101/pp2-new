<head>
<?php $__env->startSection('title'); ?>
    Admin Panel
<?php $__env->stopSection(); ?>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Admin Portal">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico">

</head>


<?php $__env->startSection('content'); ?>
    <div id="right-panel" class="right-panel">
        <div class="breadcrumbs">
            <div class="col-sm-1">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Cities</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>


        <!-- Content -->
        <div class="col-sm-12">
            <a href="addcity.blade.php" class="btn btn-primary">Add City</a>
        </div>
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">City Details</strong>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped ">
                            <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Image</th>
                                <th scope="col">Name</th>
                                <th scope="col">Desc.</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td></td>
                                <td>Lahore</td>
                                <td>Resolution of Pakistan passed in Lahore in 1940.</td>
                                <td><button class="btn btn-danger">Delete</button></td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td></td>
                                <td>Islamabad</td>
                                <td>Islamabad is capital of Pakistan.</td>
                                <td><button class="btn btn-danger">Delete</button></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /#right-panel -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/cities.blade.php ENDPATH**/ ?>