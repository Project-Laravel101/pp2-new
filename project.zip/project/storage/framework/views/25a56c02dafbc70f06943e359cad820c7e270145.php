<head>
    <?php $__env->startSection('title'); ?>
        Profile
    <?php $__env->stopSection(); ?>
</head>
<?php $__env->startSection('content'); ?>
    <div class="container bg-flat-color-2">

<!--options Nav-->
        <div class="row ">
            <div class="col-md-12">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a href="" data-target="#profile" data-toggle="tab" class="nav-link active">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a href="" data-target="#messages" data-toggle="tab" class="nav-link">Messages</a>
                    </li>
                    <li class="nav-item">
                        <a href="" data-target="#edit" data-toggle="tab" class="nav-link">Edit</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<br><br>
    <div class="container-fluid ">
        <div class="col-sm-1"></div>
        <img src="//placehold.it/150" class="m-x-auto img-fluid" alt="...">

        <form action="#" >
            <br>
        <div>
            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-2 col-form-label">Name</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="1" placeholder="Name">
                </div>
            </div>
            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-5">
                    <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-5">
                    <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-7">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
                </div>
        </form>
    </div>




    <?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/admin/adminprofile.blade.php ENDPATH**/ ?>