<head>
    <?php $__env->startSection('title'); ?>
        Categories
    <?php $__env->stopSection(); ?>
</head>
<?php $__env->startSection('breadcrumb-nav'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cities</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="col-lg-1"></div>
    <div class="col-lg-7">
        <a href="/categories/create"><button class="btn btn-primary">Add Category</button></a>
        <br><br><br>
        <?php if(count($categories)>0): ?>
        <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <thead class="table-striped thead-light">
            <tr>
                <th scope="col"><?php echo e($category->id); ?></th>
                <th scope="col"><?php echo e($category->name); ?></th>
                <th> <form action="<?php echo e(action('CategoryController@destroy', $category->id)); ?>" method="post" >
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-link">Delete</button>
                    </form>
                </th>
            </tr>
            </thead>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
            <?php echo e($categories->links()); ?>

        <?php else: ?>
            <h2>No Data has been Added</h2>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/category/categories.blade.php ENDPATH**/ ?>