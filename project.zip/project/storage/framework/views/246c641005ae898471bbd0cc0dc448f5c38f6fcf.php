<head>
    <?php $__env->startSection('title'); ?>
       Edit City
    <?php $__env->stopSection(); ?>
</head>

<?php $__env->startSection('breadcrumb-nav'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cities</li>
            <li class="breadcrumb-item active" aria-current="page">Edit-City</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-2"></div>
    <div class="col-lg-auto">
        <div class="card text-white bg-dark mb-3">
            <div class="card-header">
                <strong class="card-title">Edit City</strong>
            </div>
            <div class="card-body">

                <div id="pay-invoice">
                    <div class="card-body">
                        <form action="'CityController@update', $cities->id}" method="post" class="form-horizontal" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="text-input" class=" form-control-label">Name</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <textarea type="text" name="name" class="form-control text-white bg-dark mb-3" ><?php echo e($cities->name); ?></textarea>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="text-input" class=" form-control-label">Image</label>
                                </div>
                                <div class="col-12 col-md-7">
                                    <input type="file" name="c_img" placeholder="Upload">
                                </div>
                            </div>
                            <div class="row form-group"></div>
                            <div class="row form-group">
                                <div class="col-12 col-md-5">
                                </div>
                                <div class="col col-md-4">
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                                <div class="col-12 col-md-3">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/city/editcity.blade.php ENDPATH**/ ?>