<head>
    <?php $__env->startSection('title'); ?>
      Admin Home
    <?php $__env->stopSection(); ?>
</head>
<?php $__env->startSection('breadcrumb-nav'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Admin</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/adminhome.blade.php ENDPATH**/ ?>