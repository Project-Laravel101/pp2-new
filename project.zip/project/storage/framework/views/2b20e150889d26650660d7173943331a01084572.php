<!doctype html>
<html lang="en">
<?php echo $__env->make('inc.leftpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">


    <title><?php echo $__env->yieldContent('title'); ?></title>


    <link rel="stylesheet" href="<?php echo e(asset('css/master/bootstrap.min.css')); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset("css/master/font-awesome.min.css")); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset("css/master/themify-icons.css")); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset("css/master/flag-icon.min.css")); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset("css/master/cs-skin-elastic.css")); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>" >
    <link rel='stylesheet' type='text/css' href="<?php echo e(asset("fonts/OpenSans.css")); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<div>
    <?php echo $__env->yieldContent('content'); ?>
</div>
    <script src="<?php echo e(asset('js/master/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/master/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/master/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/master/main.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/inc/master.blade.php ENDPATH**/ ?>