<head>
    <?php $__env->startSection('title'); ?>
        Admin Panel
        <link rel="shortcut icon" href="<?php echo e(asset('images/a.png')); ?>">
    <?php $__env->stopSection(); ?>
</head>


<?php $__env->startSection('content'); ?>

    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Dashboard</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="#">Dashboard</a></li>
                        <li class="active">Cities</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
    <strong class="card-title">Add New City</strong>
            </div>
            <div class="card-body">

                <div id="pay-invoice">
                    <div class="card-body">
                        <form action="" method="post" novalidate="novalidate">
                            <div class="form-group has-success">
                                <label for="cc-name" class="control-label mb-1">Name</label>
                                <input id="cc-name" name="cc-name" type="text" placeholder="Enter city name" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the city name" autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error">
                                <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                            </div>
                            <div class="form-group has-success">
                                <label for="cc-name" class="control-label mb-1">Description</label>
                                <textarea name="textarea-input" id="textarea-input" rows="9" placeholder="Enter city description" class="form-control"></textarea>
                            </div>
                            <div>
                                <button type="button" class="btn btn-secondary"><i class="fa fa-link"></i> &nbsp;Browse</button>
                            </div>
                            </br>
                            <div>
                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                    <i class="fa fa-lock fa-lg"></i>&nbsp;
                                    <span id="payment-button-amount">Save</span>
                                    <span id="payment-button-sending" style="display:none;">Sending…</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umair\Desktop\FYP proj\project\resources\views/addcity.blade.php ENDPATH**/ ?>